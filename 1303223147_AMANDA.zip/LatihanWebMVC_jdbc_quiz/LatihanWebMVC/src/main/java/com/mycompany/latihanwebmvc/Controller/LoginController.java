package com.mycompany.latihanwebmvc.Controller;

import com.mycompany.latihanwebmvc.Model.User; // Import class User dari package Model
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;

@WebServlet("/login")
public class LoginController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Ambil parameter dari view form login
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String fullName = request.getParameter("fullName");

            // Buat objek User dari inputan form login
            User user = new User(username, password, fullName);

            // Panggil method validasi login dari objek User
            if (user.isValidUser()) {
                // Jika login berhasil, arahkan ke halaman welcome.jsp
                HttpSession session = request.getSession();
                session.setAttribute("user", user); // Menyimpan objek User dalam session
                response.sendRedirect("welcome.jsp"); // Redirect ke welcome.jsp
            } else {
                // Jika login gagal, set error message dan tampilkan login.jsp
                request.setAttribute("errorMessage", "Username atau password Anda salah!");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Log error untuk debug
            e.printStackTrace();

            // Tampilkan halaman error jika ada exception
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Terjadi kesalahan dalam memproses request.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Jika method GET dipanggil, arahkan ke halaman login.jsp
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }
}